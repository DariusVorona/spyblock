# Methods Documentation

## File: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/logging_manager.py

### Methods:
- __init__
- add_log

## File: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py

### Methods:
- __init__
- load_blocklist
- apply_blocklist
- clear_rules
- add_ip
- remove_ip
- sort_blocklist
- merge_blocklist
- GetStatus
- AddIP
- RemoveIP

## File: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon.py

### Methods:
- __init__
- monitor_traffic
- stop_daemon
- __init__
- block_ip

## File: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/gui_utils.py

### Methods:
- create_label
- create_button
- get_peerblock_gui

## File: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py

### Methods:
- __init__
- init_ui
- load_blocklists
- toggle_blocklist
- download_blocklist
- delete_blocklist
- update_all_blocklists
- update_slider_style
- get_slider_style

## File: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/geoip_blocker.py

### Methods:
- __init__
- is_blocked

## File: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_dialog.py

### Methods:
- __init__
- apply_changes
- send_dbus_signal

## File: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/blocklist.py

### Methods:
- get_blocklists
- __init__
- enable_blocklist
- disable_blocklist
- load_blocklist
- download_blocklist
- auto_update_blocklists
- start_auto_update_thread

## File: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/live_display_tab.py

### Methods:
- __init__
- init_ui
- activate_firewall
- deactivate_firewall
- update_logs

## File: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/config.py

### Methods:
- __init__
- load_config
- get
- set
- save_config

## File: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/performance_monitor.py

### Methods:
- __init__
- get_stats

## File: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_tab.py

### Methods:
- __init__
- toggle_geolocation
- toggle_logging
- toggle_daemon
- toggle_protocol
- manage_blocklists
- toggle_auto_update

## File: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/tab_utils.py

### Methods:
- get_live_display_tab
- get_block_list_tab
- get_settings_tab

## File: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/main_window.py

### Methods:
- get_live_display_tab
- get_block_list_tab
- get_settings_tab
- __init__
- add_tabs

## File: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/firewall.py

### Methods:
- __init__
- activate
- deactivate
- block_protocol
- unblock_protocol
- is_protocol_blocked
- fetch_logs
- add_log

## File: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/dependency_checker.py

### Methods:
- check_dependencies

