
# Development Notes

## Version 1.8.12 Enhancements
1. **Logging System**:
   - Advanced filtering for logs.
   - Export logs in JSON and CSV formats.

2. **GeoIP Blocking**:
   - Dynamically block IPs by geographic region.
   - Integrated with the settings tab.

3. **Real-Time Monitoring**:
   - Performance monitoring GUI for blocked/allowed traffic.

## To-Do
- Add user-friendly error handling for database updates.
- Expand protocol-specific filtering with additional rules.
