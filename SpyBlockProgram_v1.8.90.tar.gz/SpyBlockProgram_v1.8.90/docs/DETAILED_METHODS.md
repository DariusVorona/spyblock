# Detailed Methods Documentation

## Method: __init__
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/logging_manager.py
- Not used anywhere.

## Method: add_log
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/logging_manager.py
- Not used anywhere.

## Method: __init__
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py

## Method: load_blocklist
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py

## Method: apply_blocklist
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py

## Method: clear_rules
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py

## Method: add_ip
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py

## Method: remove_ip
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py

## Method: sort_blocklist
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py
- Not used anywhere.

## Method: merge_blocklist
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py
- Not used anywhere.

## Method: GetStatus
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py
- Not used anywhere.

## Method: AddIP
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py
- Not used anywhere.

## Method: RemoveIP
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon_final.py
- Not used anywhere.

## Method: __init__
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon.py
- Not used anywhere.

## Method: monitor_traffic
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon.py

## Method: stop_daemon
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon.py

## Method: block_ip
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/peerblock_daemon.py
- Not used anywhere.

## Method: create_label
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/gui_utils.py
- Not used anywhere.

## Method: create_button
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/gui_utils.py
- Not used anywhere.

## Method: get_peerblock_gui
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/gui_utils.py
- Not used anywhere.

## Method: __init__
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py

## Method: init_ui
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py

## Method: load_blocklists
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py

## Method: toggle_blocklist
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py

## Method: download_blocklist
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py

## Method: delete_blocklist
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py

## Method: update_all_blocklists
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py
- Not used anywhere.

## Method: update_slider_style
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py

## Method: get_slider_style
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/block_list_tab.py

## Method: __init__
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/geoip_blocker.py
- Not used anywhere.

## Method: is_blocked
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/geoip_blocker.py
- Not used anywhere.

## Method: __init__
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_dialog.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_dialog.py

## Method: apply_changes
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_dialog.py
- Not used anywhere.

## Method: send_dbus_signal
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_dialog.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_dialog.py

## Method: get_blocklists
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/blocklist.py
- Not used anywhere.

## Method: __init__
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/blocklist.py
- Not used anywhere.

## Method: enable_blocklist
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/blocklist.py
- Not used anywhere.

## Method: disable_blocklist
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/blocklist.py
- Not used anywhere.

## Method: load_blocklist
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/blocklist.py
- Not used anywhere.

## Method: download_blocklist
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/blocklist.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/blocklist.py

## Method: auto_update_blocklists
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/blocklist.py
- Not used anywhere.

## Method: start_auto_update_thread
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/blocklist.py
- Not used anywhere.

## Method: __init__
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/live_display_tab.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/live_display_tab.py

## Method: init_ui
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/live_display_tab.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/live_display_tab.py

## Method: activate_firewall
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/live_display_tab.py
- Not used anywhere.

## Method: deactivate_firewall
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/live_display_tab.py
- Not used anywhere.

## Method: update_logs
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/live_display_tab.py
- Not used anywhere.

## Method: __init__
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/config.py
- Not used anywhere.

## Method: load_config
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/config.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/config.py

## Method: get
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/config.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/config.py
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/config.py

## Method: set
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/config.py
- Not used anywhere.

## Method: save_config
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/config.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/config.py

## Method: __init__
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/performance_monitor.py
- Not used anywhere.

## Method: get_stats
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/performance_monitor.py
- Not used anywhere.

## Method: __init__
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_tab.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_tab.py

## Method: toggle_geolocation
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_tab.py
- Not used anywhere.

## Method: toggle_logging
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_tab.py
- Not used anywhere.

## Method: toggle_daemon
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_tab.py
- Not used anywhere.

## Method: toggle_protocol
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_tab.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_tab.py
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_tab.py
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_tab.py

## Method: manage_blocklists
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_tab.py
- Not used anywhere.

## Method: toggle_auto_update
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/settings_tab.py
- Not used anywhere.

## Method: get_live_display_tab
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/tab_utils.py
- Not used anywhere.

## Method: get_block_list_tab
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/tab_utils.py
- Not used anywhere.

## Method: get_settings_tab
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/tab_utils.py
- Not used anywhere.

## Method: get_live_display_tab
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/main_window.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/main_window.py

## Method: get_block_list_tab
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/main_window.py
- Not used anywhere.

## Method: get_settings_tab
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/main_window.py
- Not used anywhere.

## Method: __init__
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/main_window.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/main_window.py

## Method: add_tabs
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/main_window.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/main_window.py

## Method: __init__
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/firewall.py
- Not used anywhere.

## Method: activate
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/firewall.py
- Not used anywhere.

## Method: deactivate
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/firewall.py
- Not used anywhere.

## Method: block_protocol
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/firewall.py
- Not used anywhere.

## Method: unblock_protocol
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/firewall.py
- Not used anywhere.

## Method: is_protocol_blocked
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/firewall.py
- Not used anywhere.

## Method: fetch_logs
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/firewall.py
- Not used anywhere.

## Method: add_log
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/firewall.py
- Used in:
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/firewall.py
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/firewall.py
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/firewall.py
  - /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/firewall.py

## Method: check_dependencies
- Defined in: /mnt/data/PeerBlockProgram_v1.8.38_1/PeerBlockProgram_v1.8.38/dependency_checker.py
- Not used anywhere.

