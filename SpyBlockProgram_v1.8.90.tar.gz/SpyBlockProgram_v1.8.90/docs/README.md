# SpyBlock Program

## Overview
SpyBlock is a network filtering tool designed to enhance online privacy by blocking inbound and outbound traffic to specified IP ranges. The program provides a GUI for configuration and monitoring, along with advanced features like geolocation blocking, protocol-specific filtering, and background operation.

---

## Features
- **IP Blocking**: Block traffic based on custom or predefined blocklists.
- **Protocol Filtering**: Toggle blocking for TCP, UDP, and ICMP protocols.
- **Geolocation Blocking**: Block IPs based on geographic regions using GeoIP databases.
- **Live Logs**: Real-time display of blocked and allowed traffic.
- **Daemon Mode**: Run the firewall in the background for continuous protection.
- **Automatic Updates**: Auto-update blocklists on a configurable schedule.
- **Cross-Platform GUI**: Built using PyQt5 for KDE compatibility.

---

## Getting Started
1. Clone the repository:
   ```bash
   git clone https://github.com/example/spyblock.git

### New Features in Version 1.8.64
- Slider toggles blocklists dynamically with visual feedback.
- Export logs in JSON and CSV formats.
- Geolocation blocking supports dynamic region filtering.

### Updates in Version 1.8.67
- **Settings Tab Enhancements**: Added a "Delete All Blocklists" button with user confirmation.
- **Blocklist Validation**: Blocklists now require valid names to be created.
- **GUI and Backend Integration**: Finalized slider functionality and backend persistence for blocklists.

### Updates in Version 1.8.68
- **Settings Tab Enhancements**: Added options for real-time blocking, protocol blocking, and predefined blocklists.
- **Logging**: Configurable verbosity for connection logs, blocklist actions, and more.
- **Real-Time Blocking**: Toggle for enabling real-time monitoring, including Normal and Aggressive modes.

### Updates in Version 1.8.69
- **Settings Tab**: Completed functionality for deleting blocklists, managing real-time blocking, and notifications.
- **Blocklist Tab**: Fully integrated with backend for blocklist management.
- **Real-Time Blocking**: Optimized for performance and reliability.

### Updates in Version 1.8.70
- **Import Fixes**: Added missing imports from utils.py to ensure full functionality.
- **Program Stability**: Improved performance and ensured that all features work as expected.

### Updates in Version 1.8.71
- **Import Fixes**: Added missing imports from utils.py to ensure full functionality.
- **Program Stability**: Improved performance and ensured that all features work as expected.

### Updates in Version 1.8.72
- **Import Fixes**: Added missing imports from utils.py to ensure full functionality.
- **Program Stability**: Enhanced performance and ensured smooth operation of all features.

### Updates in Version 1.8.73
- **Import Fixes**: Added missing imports from utils.py to ensure full functionality.
- **Program Stability**: Improved performance and ensured smooth operation of all features.

### Updates in Version 1.8.74
- **Indentation Fixes**: Resolved indentation issues across multiple files to ensure consistency.
- **Program Stability**: Improved overall program reliability.

### Updates in Version 1.8.75
- **Indentation Fixes**: Resolved all indentation issues to ensure a consistent style.
- **Program Stability**: Improved program performance and overall reliability.

### Updates in Version 1.8.77
- **Indentation Fixes**: Resolved all indentation issues across the codebase.
- **Program Stability**: Enhanced the overall performance and readability.

### Updates in Version 1.8.78
- **Indentation Fixes**: Resolved all remaining indentation issues across the program.
- **Program Stability**: Enhanced performance and overall program reliability.

### Updates in Version 1.8.79
- **Indentation Fixes**: Resolved all remaining indentation issues across the program.
- **Program Stability**: Enhanced performance and overall program reliability.

### Updates in Version 1.8.80
- **Indentation Fixes**: Resolved all remaining indentation issues across the program.
- **Program Stability**: Enhanced performance and overall program reliability.

### Updates in Version 1.8.81
- **Indentation Fixes**: Reworked the codebase for consistent indentation.
- **Program Stability**: Enhanced the program's readability and structure.

### Updates in Version 1.8.82
- **Code Rewriting**: Rewritten `blocklist.py` to fix indentation and improve code structure.
- **Functionality Enhancements**: Improved handling of blocklist management and updates.
- **Program Stability**: Enhanced the overall reliability and performance.

### Updates in Version 1.8.83
- **Periodic Update Fixes**: Fixed issues in the 'periodic_update' function to ensure correct execution.
- **Program Stability**: Enhanced the overall stability and functionality of the blocklist management system.

### Updates in Version 1.8.84
- **'get_config_value' Function**: Implemented the 'get_config_value' function to fetch configuration values from files.
- **Bug Fixes**: Resolved the import issue related to 'get_config_value'.
- **Stability Improvements**: Enhanced the overall functionality of the program.
