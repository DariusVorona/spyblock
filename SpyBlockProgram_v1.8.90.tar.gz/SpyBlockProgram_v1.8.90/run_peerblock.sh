
#!/bin/bash

# PeerBlock Run Script
# =====================
# This script provides options to install dependencies, run PeerBlock in admin or testing mode,
# and manage the background service.

# Ensure we are in the script's directory
cd "$(dirname "$0")"

# Check for Python 3
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed or not in PATH."
    exit 1
fi

# Function to check dependencies
check_dependencies() {
    missing_dependencies=0
    while read -r package; do
        # Skip PyGObject and dbus-python checks if they aren't critical
        if [[ "$package" == "PyGObject" || "$package" == "dbus-python" ]]; then
            echo "Skipping optional dependency check for $package."
            continue
        fi
        if ! python3 -c "import $package" &> /dev/null; then
            echo "Error: Python package '$package' is not installed."
            missing_dependencies=1
        fi
    done < <(sed 's/#.*//; /^[[:space:]]*$/d' requirements.txt)

    if [ $missing_dependencies -eq 1 ]; then
        echo "Some dependencies are missing."
        read -p "Do you want to install them now? (yes/no): " install_option
        if [[ "$install_option" == "yes" || "$install_option" == "y" ]]; then
            pip install -r requirements.txt
            if [ $? -ne 0 ]; then
                echo "Failed to install dependencies. Please check your setup."
                exit 1
            fi
        else
            echo "Skipping dependency installation. The program may not work fully."
        fi
    else
        echo "All critical dependencies are installed."
    fi
}

# Function to start PeerBlock in admin mode
run_program() {
    echo "Starting PeerBlock with administrative rights..."
    python3 main.py
}

# Function to start PeerBlock in testing mode
run_testing_mode() {
    echo "Starting PeerBlock in testing mode (no admin rights)..."
    python3 main.py
}

# Function to start the background service
start_daemon() {
    echo "Starting PeerBlock background service..."
    python3 peerblock_daemon.py &
    echo $! > peerblock_daemon.pid
    echo "PeerBlock daemon started with PID $(cat peerblock_daemon.pid)."
}

# Function to stop the background service
stop_daemon() {
    if [[ -f peerblock_daemon.pid ]]; then
        kill -9 $(cat peerblock_daemon.pid)
        rm -f peerblock_daemon.pid
        echo "PeerBlock daemon stopped."
    else
        echo "No running PeerBlock daemon found."
    fi
}

# Display menu options
echo "PeerBlock Program Launcher"
echo "==========================="
check_dependencies

echo "1. Run PeerBlock with admin rights (requires password)"
echo "2. Run PeerBlock in testing mode (no admin rights)"
echo "3. Start PeerBlock background service (daemon mode)"
echo "4. Stop PeerBlock background service"
read -p "Choose an option (1/2/3/4): " option

case $option in
    1)
        if [[ $EUID -ne 0 ]]; then
            echo "This option requires administrative privileges. Please run with 'sudo'."
            exit 1
        fi
        run_program
        ;;
    2)
        run_testing_mode
        ;;
    3)
        start_daemon
        ;;
    4)
        stop_daemon
        ;;
    *)
        echo "Invalid option. Exiting."
        exit 1
        ;;
esac
